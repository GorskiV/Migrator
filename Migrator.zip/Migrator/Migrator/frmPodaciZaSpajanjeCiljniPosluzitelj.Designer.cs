﻿namespace Migrator
{
    partial class frmPodaciZaSpajanjeCiljniPosluzitelj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPodaciZaSpajanjeCiljniPosluzitelj));
            this.lblPosluzitelj2 = new System.Windows.Forms.Label();
            this.txtCiljniPosluzitelj = new System.Windows.Forms.TextBox();
            this.lblKorisnickoIme2 = new System.Windows.Forms.Label();
            this.txtCiljnoKorisnickoIme = new System.Windows.Forms.TextBox();
            this.lblLozinka2 = new System.Windows.Forms.Label();
            this.txtCiljnaLozinka = new System.Windows.Forms.TextBox();
            this.btnTestirajCiljniPosluzitelj = new System.Windows.Forms.Button();
            this.btnMigriraj = new System.Windows.Forms.Button();
            this.btnNatrag3 = new System.Windows.Forms.Button();
            this.lblCiljnaBaza = new System.Windows.Forms.Label();
            this.txtCiljnaBaza = new System.Windows.Forms.TextBox();
            this.chxWindowsACiljni = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblPosluzitelj2
            // 
            this.lblPosluzitelj2.AutoSize = true;
            this.lblPosluzitelj2.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosluzitelj2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblPosluzitelj2.Location = new System.Drawing.Point(12, 33);
            this.lblPosluzitelj2.Name = "lblPosluzitelj2";
            this.lblPosluzitelj2.Size = new System.Drawing.Size(49, 23);
            this.lblPosluzitelj2.TabIndex = 1;
            this.lblPosluzitelj2.Text = "Host:";
            // 
            // txtCiljniPosluzitelj
            // 
            this.txtCiljniPosluzitelj.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtCiljniPosluzitelj.Location = new System.Drawing.Point(16, 59);
            this.txtCiljniPosluzitelj.Multiline = true;
            this.txtCiljniPosluzitelj.Name = "txtCiljniPosluzitelj";
            this.txtCiljniPosluzitelj.Size = new System.Drawing.Size(360, 26);
            this.txtCiljniPosluzitelj.TabIndex = 1;
            // 
            // lblKorisnickoIme2
            // 
            this.lblKorisnickoIme2.AutoSize = true;
            this.lblKorisnickoIme2.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKorisnickoIme2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblKorisnickoIme2.Location = new System.Drawing.Point(12, 88);
            this.lblKorisnickoIme2.Name = "lblKorisnickoIme2";
            this.lblKorisnickoIme2.Size = new System.Drawing.Size(91, 23);
            this.lblKorisnickoIme2.TabIndex = 3;
            this.lblKorisnickoIme2.Text = "Username:";
            // 
            // txtCiljnoKorisnickoIme
            // 
            this.txtCiljnoKorisnickoIme.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtCiljnoKorisnickoIme.Location = new System.Drawing.Point(16, 114);
            this.txtCiljnoKorisnickoIme.Multiline = true;
            this.txtCiljnoKorisnickoIme.Name = "txtCiljnoKorisnickoIme";
            this.txtCiljnoKorisnickoIme.Size = new System.Drawing.Size(260, 26);
            this.txtCiljnoKorisnickoIme.TabIndex = 2;
            // 
            // lblLozinka2
            // 
            this.lblLozinka2.AutoSize = true;
            this.lblLozinka2.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLozinka2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblLozinka2.Location = new System.Drawing.Point(12, 143);
            this.lblLozinka2.Name = "lblLozinka2";
            this.lblLozinka2.Size = new System.Drawing.Size(85, 23);
            this.lblLozinka2.TabIndex = 5;
            this.lblLozinka2.Text = "Password:";
            // 
            // txtCiljnaLozinka
            // 
            this.txtCiljnaLozinka.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCiljnaLozinka.Location = new System.Drawing.Point(16, 169);
            this.txtCiljnaLozinka.Multiline = true;
            this.txtCiljnaLozinka.Name = "txtCiljnaLozinka";
            this.txtCiljnaLozinka.PasswordChar = '*';
            this.txtCiljnaLozinka.Size = new System.Drawing.Size(260, 26);
            this.txtCiljnaLozinka.TabIndex = 3;
            // 
            // btnTestirajCiljniPosluzitelj
            // 
            this.btnTestirajCiljniPosluzitelj.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnTestirajCiljniPosluzitelj.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnTestirajCiljniPosluzitelj.Location = new System.Drawing.Point(16, 311);
            this.btnTestirajCiljniPosluzitelj.Name = "btnTestirajCiljniPosluzitelj";
            this.btnTestirajCiljniPosluzitelj.Size = new System.Drawing.Size(145, 33);
            this.btnTestirajCiljniPosluzitelj.TabIndex = 6;
            this.btnTestirajCiljniPosluzitelj.Text = "Test connection";
            this.btnTestirajCiljniPosluzitelj.UseVisualStyleBackColor = true;
            this.btnTestirajCiljniPosluzitelj.Click += new System.EventHandler(this.btnTestirajCiljniPosluzitelj_Click);
            // 
            // btnMigriraj
            // 
            this.btnMigriraj.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnMigriraj.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnMigriraj.Location = new System.Drawing.Point(215, 311);
            this.btnMigriraj.Name = "btnMigriraj";
            this.btnMigriraj.Size = new System.Drawing.Size(161, 33);
            this.btnMigriraj.TabIndex = 7;
            this.btnMigriraj.Text = "Start migration";
            this.btnMigriraj.UseVisualStyleBackColor = true;
            this.btnMigriraj.Click += new System.EventHandler(this.btnMigriraj_Click);
            // 
            // btnNatrag3
            // 
            this.btnNatrag3.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnNatrag3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnNatrag3.Location = new System.Drawing.Point(288, 371);
            this.btnNatrag3.Name = "btnNatrag3";
            this.btnNatrag3.Size = new System.Drawing.Size(88, 33);
            this.btnNatrag3.TabIndex = 9;
            this.btnNatrag3.Text = "Back";
            this.btnNatrag3.UseVisualStyleBackColor = true;
            this.btnNatrag3.Click += new System.EventHandler(this.btnNatrag3_Click);
            // 
            // lblCiljnaBaza
            // 
            this.lblCiljnaBaza.AutoSize = true;
            this.lblCiljnaBaza.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCiljnaBaza.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblCiljnaBaza.Location = new System.Drawing.Point(12, 201);
            this.lblCiljnaBaza.Name = "lblCiljnaBaza";
            this.lblCiljnaBaza.Size = new System.Drawing.Size(133, 23);
            this.lblCiljnaBaza.TabIndex = 14;
            this.lblCiljnaBaza.Text = "Database name:";
            // 
            // txtCiljnaBaza
            // 
            this.txtCiljnaBaza.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtCiljnaBaza.Location = new System.Drawing.Point(16, 231);
            this.txtCiljnaBaza.Multiline = true;
            this.txtCiljnaBaza.Name = "txtCiljnaBaza";
            this.txtCiljnaBaza.Size = new System.Drawing.Size(260, 26);
            this.txtCiljnaBaza.TabIndex = 5;
            // 
            // chxWindowsACiljni
            // 
            this.chxWindowsACiljni.AutoSize = true;
            this.chxWindowsACiljni.Enabled = false;
            this.chxWindowsACiljni.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.chxWindowsACiljni.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chxWindowsACiljni.Location = new System.Drawing.Point(16, 272);
            this.chxWindowsACiljni.Name = "chxWindowsACiljni";
            this.chxWindowsACiljni.Size = new System.Drawing.Size(260, 24);
            this.chxWindowsACiljni.TabIndex = 15;
            this.chxWindowsACiljni.Text = "Sql Server Windows Authentication";
            this.chxWindowsACiljni.UseVisualStyleBackColor = true;
            // 
            // frmPodaciZaSpajanjeCiljniPosluzitelj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(396, 416);
            this.Controls.Add(this.chxWindowsACiljni);
            this.Controls.Add(this.txtCiljnaBaza);
            this.Controls.Add(this.lblCiljnaBaza);
            this.Controls.Add(this.btnNatrag3);
            this.Controls.Add(this.btnMigriraj);
            this.Controls.Add(this.btnTestirajCiljniPosluzitelj);
            this.Controls.Add(this.txtCiljnaLozinka);
            this.Controls.Add(this.lblLozinka2);
            this.Controls.Add(this.txtCiljnoKorisnickoIme);
            this.Controls.Add(this.lblKorisnickoIme2);
            this.Controls.Add(this.txtCiljniPosluzitelj);
            this.Controls.Add(this.lblPosluzitelj2);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmPodaciZaSpajanjeCiljniPosluzitelj";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cloud host";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmPodaciZaSpajanjeCiljniPosluzitelj_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPosluzitelj2;
        private System.Windows.Forms.TextBox txtCiljniPosluzitelj;
        private System.Windows.Forms.Label lblKorisnickoIme2;
        private System.Windows.Forms.TextBox txtCiljnoKorisnickoIme;
        private System.Windows.Forms.Label lblLozinka2;
        private System.Windows.Forms.TextBox txtCiljnaLozinka;
        private System.Windows.Forms.Button btnTestirajCiljniPosluzitelj;
        private System.Windows.Forms.Button btnMigriraj;
        private System.Windows.Forms.Button btnNatrag3;
        private System.Windows.Forms.Label lblCiljnaBaza;
        private System.Windows.Forms.TextBox txtCiljnaBaza;
        public System.Windows.Forms.CheckBox chxWindowsACiljni;
    }
}